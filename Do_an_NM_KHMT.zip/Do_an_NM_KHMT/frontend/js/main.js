// ============================================
// CẤU HÌNH CHUNG
// ============================================
const API_BASE = 'http://localhost:8000/api';
let danhSachBaiDang = []; 
let currentApplyId = null; 

// ============================================
// CÁC HÀM TIỆN ÍCH
// ============================================
async function apiCall(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` }),
        ...options.headers
    };
    
    const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
    
    if (res.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        showToast('Phiên đăng nhập đã hết hạn!', 'error');
        setTimeout(() => window.location.href = 'dang-nhap.html', 1500);
        return;
    }

    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || data.error || 'Lỗi API');
    return data;
}

function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? '✅' : '❌';
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function formatScore(score) { return Math.round(score * 100) + '%'; }

// ============================================
// 1. HEADER (ĐỒNG BỘ AVATAR)
// ============================================
function updateHeaderAuth() {
    const userMenu = document.getElementById('user-menu');
    if (!userMenu) return;
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');

    if (token && userStr) {
        const user = JSON.parse(userStr);
        const avatarUrl = user.anh_dai_dien || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.ho_ten || 'Felix'}`;
        
        userMenu.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <div class="user-menu" style="padding: 6px 12px 6px 6px; background: var(--bg-hover); cursor: pointer;" onclick="window.location.href='ho-so.html'">
                    <img src="${avatarUrl}" alt="Avatar" class="avatar" style="object-fit: cover;">
                    <span class="user-name">${user.ho_ten}</span>
                </div>
                <button onclick="dangXuat()" class="btn btn-secondary btn-sm">Đăng xuất</button>
            </div>
        `;
    } else {
        userMenu.innerHTML = `<a href="dang-nhap.html" class="btn btn-primary">Đăng nhập</a>`;
    }
}

function dangXuat() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html'; 
    }
}

// ============================================
// 2. TRANG KHÁM PHÁ: LOAD BÀI ĐĂNG & BỘ LỌC
// ============================================
async function loadMonHocFilter() {
    const select = document.getElementById('filter-loai-nhom');
    if (!select) return;
    
    try {
        const data = await apiCall('/mon-hoc', { method: 'GET' });
        select.innerHTML = '<option value="">Tất cả môn học</option>' + 
            data.map(m => `<option value="${m.ma_mon_hoc}">${m.ma_mon} - ${m.ten_mon_hoc}</option>`).join('');
    } catch (err) {
        console.error('Lỗi tải danh sách môn học:', err);
    }
}

async function loadGroups() {
    const groupList = document.getElementById('group-list');
    const emptyState = document.getElementById('empty-state');
    const resultsCount = document.getElementById('results-count');
    
    if (!groupList) return;

    groupList.innerHTML = '<p style="text-align: center; padding: 40px; color: var(--text-muted); grid-column: 1 / -1;">Đang tải bài đăng...</p>';
    
    try {
        const data = await apiCall('/bai-dang', { method: 'GET' });
        danhSachBaiDang = data.danhSach || [];
        
        // Sắp xếp giảm dần theo độ tương thích
        danhSachBaiDang.sort((a, b) => (b.diemTuongThich || 0) - (a.diemTuongThich || 0));

        if (danhSachBaiDang.length === 0) {
            groupList.innerHTML = '';
            if (emptyState) emptyState.style.display = 'block';
            if (resultsCount) resultsCount.textContent = '0 bài đăng';
        } else {
            if (emptyState) emptyState.style.display = 'none';
            groupList.innerHTML = danhSachBaiDang.map(bd => renderGroupCard(bd)).join('');
            if (resultsCount) resultsCount.textContent = `${danhSachBaiDang.length} bài đăng`;
        }
    } catch (err) {
        groupList.innerHTML = `<p style="color: #EF4444; text-align: center; grid-column: 1 / -1;">Lỗi tải dữ liệu!</p>`;
    }
}

function renderGroupCard(baiDang) {
    const score = baiDang.diemTuongThich || 0.5; 
    const scorePercent = formatScore(score);
    const scoreColor = score >= 0.8 ? '#4D6BFE' : score >= 0.5 ? '#F59E0B' : '#EF4444';
    
    return `
        <div class="group-card" onclick="openGroupModal(${baiDang.maBaiDang})">
            <div class="group-card-header">
                <h3 class="group-title">${baiDang.tieuDe}</h3>
                <div class="group-type">Môn: ${baiDang.tenMonHoc || 'Chưa xác định'}</div>
            </div>
            
            <p class="group-desc">${baiDang.moTaBaiDang || 'Chưa có mô tả chi tiết.'}</p>
            
            <div class="group-meta">
                <span class="group-meta-item">Địa điểm: <strong>${baiDang.diaDiem || 'Online'}</strong></span>
                <span class="group-meta-item">Cần tuyển: <strong>${baiDang.soLuongCanTuyen} thành viên</strong></span>
                <span class="group-meta-item">Sĩ số: <strong>${baiDang.soThanhVienHienTai}/${baiDang.soThanhVienToiDa}</strong></span>
            </div>
            
            <div class="match-score">
                <div class="match-score-value" style="color: ${scoreColor};">${scorePercent}</div>
                <div class="match-score-label">Độ tương thích</div>
                <div class="match-score-bar">
                    <div class="match-score-fill" style="width: ${scorePercent}; background: ${scoreColor};"></div>
                </div>
            </div>
            
            <div class="group-actions">
                <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation(); openGroupModal(${baiDang.maBaiDang})">Chi tiết</button>
                <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); guiYeuCau(${baiDang.maBaiDang})">Ứng tuyển</button>
            </div>
        </div>
    `;
}

// ============================================
// 3. MODAL CHI TIẾT NHÓM
// ============================================
function openGroupModal(maBaiDang) {
    const bd = danhSachBaiDang.find(b => b.maBaiDang === maBaiDang);
    if (!bd) return;
    
    document.getElementById('modal-title').textContent = bd.tenNhom;
    document.getElementById('modal-subtitle').textContent = `Môn: ${bd.tenMonHoc || '—'} | Lĩnh vực: ${bd.linhVuc || '—'}`;
    document.getElementById('modal-desc').textContent = bd.moTaBaiDang || 'Chưa có mô tả';
    
    let reqHtml = '';
    if (bd.yeuCauCung) reqHtml += `<p style="margin-bottom: 8px;"><strong>Bắt buộc:</strong> ${bd.yeuCauCung}</p>`;
    if (bd.yeuCauMem) reqHtml += `<p style="margin-bottom: 8px;"><strong>Ưu tiên:</strong> ${bd.yeuCauMem}</p>`;
    if (bd.yeuCauGpa > 0) reqHtml += `<p><strong>GPA tối thiểu:</strong> ${bd.yeuCauGpa}</p>`;
    document.getElementById('modal-requirements').innerHTML = reqHtml || 'Không có yêu cầu cụ thể.';
    
    document.getElementById('modal-other').innerHTML = `
        <p style="margin-bottom: 8px;"><strong>Hình thức:</strong> ${bd.hinhThuc || '—'}</p>
        <p style="margin-bottom: 8px;"><strong>Địa điểm:</strong> ${bd.diaDiem || '—'}</p>
        <p><strong>Trạng thái:</strong> Đang tuyển ${bd.soLuongCanTuyen} thành viên</p>
    `;
    
    document.getElementById('modal-actions').innerHTML = `
        <button class="btn btn-secondary" onclick="closeGroupModal()">Đóng</button>
        <button class="btn btn-primary" onclick="closeGroupModal(); guiYeuCau(${bd.maBaiDang});">Gửi ứng tuyển</button>
    `;
    
    document.getElementById('group-modal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeGroupModal() {
    document.getElementById('group-modal').style.display = 'none';
    document.body.style.overflow = '';
}

// ============================================
// 4. ỨNG TUYỂN
// ============================================
function guiYeuCau(maBaiDang) {
    if (!localStorage.getItem('token')) {
        showToast('Vui lòng đăng nhập trước khi ứng tuyển!', 'error');
        setTimeout(() => window.location.href = 'dang-nhap.html', 1500);
        return;
    }

    currentApplyId = maBaiDang;
    document.getElementById('ung-tuyen-loi-nhan').value = ''; 
    document.getElementById('modal-ung-tuyen').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModalUngTuyen() {
    document.getElementById('modal-ung-tuyen').style.display = 'none';
    currentApplyId = null;
    document.body.style.overflow = '';
}

async function submitUngTuyen() {
    if (!currentApplyId) return;
    
    const btn = document.querySelector('#modal-ung-tuyen .btn-primary');
    const loiNhan = document.getElementById('ung-tuyen-loi-nhan').value.trim();
    
    btn.textContent = 'Đang gửi...';
    btn.disabled = true;

    try {
        const data = await apiCall(`/bai-dang/${currentApplyId}/ung-tuyen`, {
            method: 'POST',
            body: JSON.stringify({ loi_nhan: loiNhan })
        });
        showToast(data.message || 'Đã gửi ứng tuyển thành công!', 'success');
        closeModalUngTuyen();
    } catch (err) {
        showToast(err.message || 'Có lỗi xảy ra!', 'error');
    } finally {
        btn.textContent = 'Gửi ứng tuyển';
        btn.disabled = false;
    }
}

// ============================================
// KHỞI CHẠY KHI TẢI TRANG
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    updateHeaderAuth();
    if (document.getElementById('group-list')) {
        loadGroups();
        loadMonHocFilter(); // Gọi hàm load môn học vào ô Select
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeGroupModal();
        closeModalUngTuyen();
    }
});