const urlParams = new URLSearchParams(window.location.search);
const maNhom = parseInt(urlParams.get('maNhom'));
let currentUserId = null;
let ws = null;
let isTruongNhom = false;

document.addEventListener('DOMContentLoaded', async () => {
    if (!localStorage.getItem('token') || !maNhom) { window.location.href = 'nhom-cua-ban.html'; return; }
    
    const userStr = localStorage.getItem('user');
    if (userStr) {
        const user = JSON.parse(userStr);
        currentUserId = user.ma_tai_khoan;
    }

    try {
        const data = await apiCall(`/nhom/${maNhom}/chi-tiet`, { method: 'GET' });
        document.getElementById('chat-ten-nhom').textContent = data.tenNhom;
        // So sánh ID người tạo nhóm với ID người đang đăng nhập để phân quyền
        if (data.nguoiTao === currentUserId) isTruongNhom = true; 
    } catch (err) { console.error(err); }

    await loadLichSuTinNhan();
    connectWebSocket();

    document.getElementById('chat-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if (text && ws && ws.readyState === WebSocket.OPEN) {
            ws.send(text);
            input.value = '';
        }
    });
});

async function loadLichSuTinNhan() {
    try {
        const data = await apiCall(`/nhom/${maNhom}/tin-nhan`, { method: 'GET' });
        const chatBox = document.getElementById('chat-box');
        chatBox.innerHTML = '';
        data.forEach(msg => renderTinNhan(msg));
    } catch (err) { console.error('Lỗi tải tin nhắn:', err); }
}

function connectWebSocket() {
    const wsUrl = API_BASE.replace('http://', 'ws://').replace('/api', '');
    ws = new WebSocket(`${wsUrl}/ws/chat/${maNhom}/${currentUserId}`);
    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (!msg.system) { renderTinNhan(msg); }
    };
    ws.onclose = () => { setTimeout(connectWebSocket, 3000); };
}

function renderTinNhan(msg) {
    const chatBox = document.getElementById('chat-box');
    const isMine = msg.ma_tai_khoan === currentUserId;
    const avatarUrl = msg.anh_dai_dien || `https://api.dicebear.com/7.x/adventurer/svg?seed=${msg.ten_nguoi_gui}`;
    
    const div = document.createElement('div');
    div.className = `msg-wrapper ${isMine ? 'mine' : 'other'}`;
    div.innerHTML = `
        <img src="${avatarUrl}" class="msg-avatar" alt="Avatar">
        <div class="msg-content">
            ${!isMine ? `<div class="msg-info">${msg.ten_nguoi_gui} • ${msg.ngay_gui}</div>` : ''}
            <div class="msg-bubble">${msg.noi_dung}</div>
        </div>
    `;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// MODAL HOẠT ĐỘNG
function openActivityModal() {
    document.getElementById('activity-modal').style.display = 'flex';
    switchActivityTab('calendar');
    loadDanhSachLichHop();
    loadDanhSachDeadline();
}
function closeActivityModal() { document.getElementById('activity-modal').style.display = 'none'; }
function switchActivityTab(tab) {
    document.getElementById('tab-calendar').classList.remove('active');
    document.getElementById('tab-deadline').classList.remove('active');
    document.getElementById('content-calendar').style.display = 'none';
    document.getElementById('content-deadline').style.display = 'none';

    if (tab === 'calendar') {
        document.getElementById('tab-calendar').classList.add('active');
        document.getElementById('content-calendar').style.display = 'block';
    } else {
        document.getElementById('tab-deadline').classList.add('active');
        document.getElementById('content-deadline').style.display = 'block';
    }
}

// LỊCH HỌP
async function loadDanhSachLichHop() {
    const list = document.getElementById('list-lich-hop');
    list.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Đang tải...</p>';
    try {
        const data = await apiCall(`/nhom/${maNhom}/lich-hop`, { method: 'GET' });
        if (data.length === 0) { list.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Chưa có lịch họp.</p>'; return; }
        
        list.innerHTML = data.map(lh => {
            let timeStr = lh.thoi_gian_bat_dau ? new Date(lh.thoi_gian_bat_dau).toLocaleString('vi-VN') : "—";
            // Chỉ hiển thị nút Xóa nếu là Trưởng nhóm
            const btnXoa = isTruongNhom ? `<button class="btn btn-secondary btn-sm" style="color:#EF4444; border-color:#EF4444;" onclick="xoaLichHop(${lh.ma_lich_hop})">Xóa</button>` : '';
            return `<div class="task-item"><div><div class="task-title">${lh.tieu_de}</div><div class="task-time">${timeStr} | ${lh.dia_diem || '—'}</div></div>${btnXoa}</div>`;
        }).join('');
    } catch (err) { list.innerHTML = '<p style="color: red; text-align: center;">Lỗi tải lịch!</p>'; }
}
function moModalTaoLich() { document.getElementById('modal-tao-lich').style.display = 'flex'; }
function closeModalTaoLich() { document.getElementById('modal-tao-lich').style.display = 'none'; }
async function xuLyTaoLich() {
    const tieuDe = document.getElementById('lich-tieu-de').value.trim();
    const ngay = document.getElementById('lich-ngay').value;
    let bd = document.getElementById('lich-gio-bat-dau').value;
    let kt = document.getElementById('lich-gio-ket-thuc').value;
    if(!tieuDe || !ngay || !bd || !kt) { showToast('Nhập thiếu thông tin!', 'error'); return; }
    bd = bd.length === 4 ? '0'+bd : bd; kt = kt.length === 4 ? '0'+kt : kt;
    const payload = { tieu_de: tieuDe, thoi_gian_bat_dau: `${ngay}T${bd}:00`, thoi_gian_ket_thuc: `${ngay}T${kt}:00`, dia_diem: document.getElementById('lich-dia-diem').value, noi_dung: document.getElementById('lich-noi-dung').value };
    try { await apiCall(`/nhom/${maNhom}/lich-hop`, { method: 'POST', body: JSON.stringify(payload) }); showToast('Tạo lịch thành công!', 'success'); closeModalTaoLich(); loadDanhSachLichHop(); } catch (err) { showToast('Lỗi!', 'error'); }
}
async function xoaLichHop(id) {
    if(!confirm('Xóa lịch họp này?')) return;
    await apiCall(`/nhom/${maNhom}/lich-hop/${id}`, { method: 'DELETE' });
    loadDanhSachLichHop();
}

// DEADLINE
async function loadDanhSachDeadline() {
    const list = document.getElementById('list-deadline');
    list.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Đang tải...</p>';
    try {
        const data = await apiCall(`/nhom/${maNhom}/deadline`, { method: 'GET' });
        if (data.length === 0) { list.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Chưa có deadline nào.</p>'; return; }
        list.innerHTML = data.map(dl => {
            let timeStr = dl.han_chot ? new Date(dl.han_chot).toLocaleString('vi-VN') : "—";
            const isDone = dl.trang_thai === 'da_xong';
            const btnXoa = isTruongNhom ? `<button class="btn btn-secondary btn-sm" style="color:#EF4444; border-color:#EF4444;" onclick="xoaDeadline(${dl.ma_deadline})">Xóa</button>` : '';
            return `<div class="task-item ${isDone ? 'done' : ''}"><div><div class="task-title" style="${isDone ? 'text-decoration: line-through;' : ''}">${dl.tieu_de}</div><div class="task-time">${timeStr}</div>${dl.mo_ta ? `<div style="font-size: 13px; color: var(--text-secondary); margin-top: 4px;">${dl.mo_ta}</div>` : ''}</div><div style="display: flex; gap: 8px;"><button class="btn ${isDone ? 'btn-secondary' : 'btn-primary'} btn-sm" onclick="doiTrangThaiDL(${dl.ma_deadline})">${isDone ? 'Hoàn tác' : 'Đã xong'}</button>${btnXoa}</div></div>`;
        }).join('');
    } catch (err) { list.innerHTML = '<p style="color: red; text-align: center;">Lỗi tải deadline!</p>'; }
}
function moModalTaoDeadline() { document.getElementById('modal-tao-deadline').style.display = 'flex'; }
function closeModalTaoDeadline() { document.getElementById('modal-tao-deadline').style.display = 'none'; }
async function xuLyTaoDeadline() {
    const tieuDe = document.getElementById('dl-tieu-de').value.trim();
    const ngay = document.getElementById('dl-ngay').value;
    let gio = document.getElementById('dl-gio').value;
    const moTa = document.getElementById('dl-mo-ta').value.trim();
    if(!tieuDe || !ngay || !gio) { showToast('Nhập thiếu thông tin!', 'error'); return; }
    gio = gio.length === 4 ? '0'+gio : gio;
    const payload = { tieu_de: tieuDe, han_chot: `${ngay}T${gio}:00`, mo_ta: moTa };
    try { await apiCall(`/nhom/${maNhom}/deadline`, { method: 'POST', body: JSON.stringify(payload) }); showToast('Tạo Deadline thành công!', 'success'); closeModalTaoDeadline(); loadDanhSachDeadline(); } catch (err) { showToast('Lỗi!', 'error'); }
}
async function doiTrangThaiDL(id) {
    await apiCall(`/nhom/${maNhom}/deadline/${id}/trang-thai`, { method: 'PUT' });
    loadDanhSachDeadline();
}
async function xoaDeadline(id) {
    if(!confirm('Xóa deadline này?')) return;
    await apiCall(`/nhom/${maNhom}/deadline/${id}`, { method: 'DELETE' });
    loadDanhSachDeadline();
}