import os
import shutil
import uuid
from sqlalchemy import Column, Integer, String, Text, Float, Date, DateTime, ForeignKey, func
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, Depends, Header, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from pydantic import BaseModel
from jose import jwt, JWTError

from database import get_db
import models
from auth import hash_password, verify_password, create_access_token, SECRET_KEY, ALGORITHM

app = FastAPI(title="API Hệ Thống Ghép Nhóm")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
os.makedirs("uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

def get_current_user(authorization: str = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(status_code=401, detail="Chưa đăng nhập")
    try:
        payload = jwt.decode(authorization.split(" ")[1], SECRET_KEY, algorithms=[ALGORITHM])
        user = db.query(models.TaiKhoan).filter(models.TaiKhoan.ma_tai_khoan == int(payload.get("sub"))).first()
        if not user: raise HTTPException(status_code=401, detail="Tài khoản không tồn tại")
        return user
    except JWTError: raise HTTPException(status_code=401, detail="Token không hợp lệ")

# ==========================================
# THUẬT TOÁN TÍNH ĐIỂM TƯƠNG THÍCH
# ==========================================
def tinh_diem_tuong_thich(db: Session, sinh_vien: models.SinhVien, nhom: models.NhomHoc, bai_dang: models.BaiDangTuyen):
    thanh_viens = db.query(models.SinhVien.lich_ranh_bit).join(
        models.ThanhVienNhom, models.SinhVien.ma_tai_khoan == models.ThanhVienNhom.ma_tai_khoan
    ).filter(models.ThanhVienNhom.ma_nhom == nhom.ma_nhom).all()
    
    lich_chung = [0] * 21
    if thanh_viens:
        for tv in thanh_viens:
            lich_str = tv.lich_ranh_bit or "000000000000000000000"
            for i in range(21):
                if lich_str[i] == '1': lich_chung[i] += 1
        so_nguoi_can = max(1, len(thanh_viens) // 2)
        lich_chung_bit = "".join(['1' if x >= so_nguoi_can else '0' for x in lich_chung])
    else: lich_chung_bit = "000000000000000000000"

    sv_lich = sinh_vien.lich_ranh_bit or "000000000000000000000"
    giao = sum(1 for i in range(21) if sv_lich[i] == '1' and lich_chung_bit[i] == '1')
    hop = sum(1 for i in range(21) if sv_lich[i] == '1' or lich_chung_bit[i] == '1')
    diem_lich = (giao / hop) if hop > 0 else 0.5

    diem_ky_nang = 1.0 
    if bai_dang.yeu_cau_ky_nang:
        try:
            ds_kn_yeu_cau = [int(k) for k in bai_dang.yeu_cau_ky_nang.split(",") if k.isdigit()]
            if ds_kn_yeu_cau:
                sv_kns = db.query(models.KyNangSinhVien.ma_ky_nang).filter(models.KyNangSinhVien.ma_tai_khoan == sinh_vien.ma_tai_khoan).all()
                sv_kn_ids = [k.ma_ky_nang for k in sv_kns]
                match = sum(1 for k in ds_kn_yeu_cau if k in sv_kn_ids)
                diem_ky_nang = match / len(ds_kn_yeu_cau)
        except: pass

    diem_gpa = 1.0
    if bai_dang.yeu_cau_gpa and bai_dang.yeu_cau_gpa > 0:
        sv_gpa = sinh_vien.gpa or 0.0
        diem_gpa = min(1.0, sv_gpa / bai_dang.yeu_cau_gpa)
    diem_hoc_van = (diem_gpa * 0.7) + (0.8 * 0.3) 

    diem_uy_tin = (sinh_vien.diem_uy_tin or 5.0) / 5.0

    diem_so_thich = 1.0
    if bai_dang.yeu_cau_so_thich:
        try:
            ds_tag_yeu_cau = [int(x) for x in bai_dang.yeu_cau_so_thich.split(",") if x.isdigit()]
            if ds_tag_yeu_cau:
                sv_tags = db.query(models.SoThichSinhVien.ma_so_thich).filter(models.SoThichSinhVien.ma_tai_khoan == sinh_vien.ma_tai_khoan).all()
                sv_tag_ids = [t.ma_so_thich for t in sv_tags]
                match_tag = sum(1 for t in ds_tag_yeu_cau if t in sv_tag_ids)
                diem_so_thich = match_tag / len(ds_tag_yeu_cau)
        except: pass

    tong_diem = (0.40 * diem_lich) + (0.25 * diem_ky_nang) + (0.15 * diem_hoc_van) + (0.10 * diem_uy_tin) + (0.10 * diem_so_thich)
    return round(tong_diem, 2)

# ==========================================
# SCHEMA DỮ LIỆU
# ==========================================
class DangKyRequest(BaseModel):
    email: str
    mat_khau: str
    ho_ten: str
    mssv: Optional[str] = None
    ma_sinh_vien: Optional[str] = None

class DangNhapRequest(BaseModel):
    email: str
    mat_khau: str

class CapNhatHoSoRequest(BaseModel):
    chuyen_nganh: str = ""
    lop_sinh_hoat: str = ""
    mo_ta_ban_than: str = ""
    nien_khoa: int = 0
    gpa: float = 0.0
    muc_tieu_hoc_tap: str = ""

class TaoNhomRequest(BaseModel):
    ten_nhom: str
    ma_mon_hoc: int
    linh_vuc: str = ""
    mo_ta: str
    mo_ta_de_tai: str = ""
    muc_tieu: str = ""
    hinh_thuc_hoat_dong: str
    dia_diem_co_dinh: str
    so_thanh_vien_toi_da: int = 5

# ==========================================
# API DANH MỤC
# ==========================================
@app.get("/api/mon-hoc")
def lay_mon_hoc(authorization: str = Header(None), db: Session = Depends(get_db)):
    user_major = "Tất cả"
    if authorization and authorization.startswith("Bearer "):
        try:
            token = authorization.split(" ")[1]
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            ma_tai_khoan = int(payload.get("sub"))
            sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == ma_tai_khoan).first()
            if sv and sv.chuyen_nganh: user_major = sv.chuyen_nganh
        except: pass

    mon_hocs = db.query(models.MonHoc).filter(
        (models.MonHoc.nganh_ap_dung == "Tất cả") | (models.MonHoc.nganh_ap_dung == user_major)
    ).all()

    return [{"ma_mon_hoc": m.ma_mon_hoc, "ma_mon": m.ma_mon, "ten_mon_hoc": m.ten_mon_hoc, "nhom_mon_hoc": m.nhom_mon_hoc} for m in mon_hocs]

@app.get("/api/danh-muc/ky-nang")
def lay_ky_nang(db: Session = Depends(get_db)):
    return db.query(models.KyNang).all()

@app.get("/api/danh-muc/so-thich")
def lay_so_thich(db: Session = Depends(get_db)):
    return db.query(models.SoThich).all()

@app.get("/api/danh-muc/bang-cap")
def lay_danh_muc_bang_cap(db: Session = Depends(get_db)): 
    return db.query(models.LoaiBangCap).all()

# ==========================================
# API ĐĂNG NHẬP / ĐĂNG KÝ / HỒ SƠ
# ==========================================
@app.post("/api/dang-ky")
@app.post("/api/dang-ky")
def dang_ky(req: DangKyRequest, db: Session = Depends(get_db)):
    # 1. Kiểm tra Email đã tồn tại chưa
    if db.query(models.TaiKhoan).filter(models.TaiKhoan.email == req.email).first(): 
        return {"error": "Email này đã được sử dụng!"}
    
    # Lấy MSSV từ request
    final_mssv = req.mssv if req.mssv else req.ma_sinh_vien
    
    # 2. Kiểm tra MSSV đã tồn tại chưa (QUAN TRỌNG)
    if db.query(models.SinhVien).filter(models.SinhVien.mssv == final_mssv).first():
        return {"error": "Mã số sinh viên này đã được đăng ký bởi tài khoản khác!"}
    
    # 3. Tạo tài khoản
    new_tk = models.TaiKhoan(
        email=req.email, 
        mat_khau_hash=hash_password(req.mat_khau), 
        loai_tai_khoan="sinh_vien", 
        trang_thai="hoat_dong"
    )
    db.add(new_tk)
    db.commit()
    db.refresh(new_tk)
    
    # 4. Tạo hồ sơ sinh viên
    db.add(models.SinhVien(
        ma_tai_khoan=new_tk.ma_tai_khoan, 
        mssv=final_mssv, 
        ho_ten=req.ho_ten
    ))
    db.commit()
    
    return {"message": "Đăng ký thành công!"}

@app.post("/api/dang-nhap")
def dang_nhap(req: DangNhapRequest, db: Session = Depends(get_db)):
    tk = db.query(models.TaiKhoan).filter(models.TaiKhoan.email == req.email).first()
    if not tk or not verify_password(req.mat_khau, tk.mat_khau_hash): return {"error": "Sai email hoặc mật khẩu!"}
    token = create_access_token(data={"sub": str(tk.ma_tai_khoan), "email": tk.email})
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == tk.ma_tai_khoan).first()
    return {
        "message": "Đăng nhập thành công!", "access_token": token, 
        "user": {"ma_tai_khoan": tk.ma_tai_khoan, "ho_ten": sv.ho_ten if sv else "Sinh viên", "anh_dai_dien": sv.anh_dai_dien if sv else ""}
    }

@app.get("/api/sinh-vien/ho-so")
def lay_ho_so(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == current_user.ma_tai_khoan).first()
    if not sv: raise HTTPException(status_code=404, detail="Không tìm thấy hồ sơ")
    return {
        "ho_ten": sv.ho_ten, "email": current_user.email, "anh_dai_dien": sv.anh_dai_dien or "",
        "mssv": sv.mssv, "chuyen_nganh": sv.chuyen_nganh or "", "lop_sinh_hoat": sv.lop_sinh_hoat or "",
        "mo_ta_ban_than": sv.mo_ta_ban_than or "", "lich_ranh_bit": sv.lich_ranh_bit or "000000000000000000000",
        "nien_khoa": sv.nien_khoa or 0, "gpa": sv.gpa or 0.0, "muc_tieu_hoc_tap": sv.muc_tieu_hoc_tap or ""
    }

@app.put("/api/sinh-vien/ho-so")
def cap_nhat_ho_so(req: CapNhatHoSoRequest, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == current_user.ma_tai_khoan).first()
    if not sv: raise HTTPException(status_code=404, detail="Không tìm thấy hồ sơ")
    sv.chuyen_nganh = req.chuyen_nganh; sv.lop_sinh_hoat = req.lop_sinh_hoat
    sv.mo_ta_ban_than = req.mo_ta_ban_than; sv.nien_khoa = req.nien_khoa
    sv.gpa = req.gpa; sv.muc_tieu_hoc_tap = req.muc_tieu_hoc_tap
    db.commit(); return {"message": "Cập nhật hồ sơ thành công!"}

@app.post("/api/tai-khoan/avatar")
def upload_avatar(file: UploadFile = File(...), current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    file_name = f"{uuid.uuid4().hex}.{file.filename.split('.')[-1]}"
    with open(f"uploads/{file_name}", "wb") as buffer: shutil.copyfileobj(file.file, buffer)
    url = f"http://localhost:8000/uploads/{file_name}"
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == current_user.ma_tai_khoan).first()
    sv.anh_dai_dien = url; db.commit(); return {"message": "Cập nhật ảnh thành công!", "avatar_url": url}

@app.get("/api/lich-ranh")
def lay_lich_ranh(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == current_user.ma_tai_khoan).first()
    return {"lich_ranh_bit": sv.lich_ranh_bit or "000000000000000000000"}

@app.put("/api/lich-ranh")
def cap_nhat_lich_ranh(req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == current_user.ma_tai_khoan).first()
    sv.lich_ranh_bit = req.get("lich_ranh_bit"); sv.cap_nhat_lich_cuoi = datetime.now(); db.commit(); return {"message": "OK"}

@app.get("/api/sinh-vien/ky-nang")
def get_sv_ky_nang(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    res = db.query(models.KyNangSinhVien.ma_ky_nang).filter(models.KyNangSinhVien.ma_tai_khoan == current_user.ma_tai_khoan).all()
    return {"danhSach": [r.ma_ky_nang for r in res]}

@app.post("/api/sinh-vien/ky-nang")
def luu_sv_ky_nang(req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(models.KyNangSinhVien).filter(models.KyNangSinhVien.ma_tai_khoan == current_user.ma_tai_khoan).delete()
    for ma in req.get("danh_sach_ma", []): db.add(models.KyNangSinhVien(ma_tai_khoan=current_user.ma_tai_khoan, ma_ky_nang=ma, trinh_do='co_ban'))
    db.commit(); return {"message": "Lưu kỹ năng thành công!"}

@app.get("/api/sinh-vien/so-thich")
def get_sv_so_thich(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    res = db.query(models.SoThichSinhVien.ma_so_thich).filter(models.SoThichSinhVien.ma_tai_khoan == current_user.ma_tai_khoan).all()
    return {"danhSach": [r.ma_so_thich for r in res]}

@app.post("/api/sinh-vien/so-thich")
def luu_sv_so_thich(req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(models.SoThichSinhVien).filter(models.SoThichSinhVien.ma_tai_khoan == current_user.ma_tai_khoan).delete()
    for ma in req.get("danh_sach_ma", []): db.add(models.SoThichSinhVien(ma_tai_khoan=current_user.ma_tai_khoan, ma_so_thich=ma))
    db.commit(); return {"message": "Lưu sở thích thành công!"}

@app.get("/api/sinh-vien/bang-cap")
def lay_bang_cap(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.BangCapSinhVien, models.LoaiBangCap).join(models.LoaiBangCap, models.LoaiBangCap.ma_loai_bang_cap == models.BangCapSinhVien.ma_loai_bang_cap).filter(models.BangCapSinhVien.ma_tai_khoan == current_user.ma_tai_khoan).all()
    return {"danhSach": [{"ten_bang_cap": loai_bc.ten_bang_cap, "loai": loai_bc.loai, "diem_so": bc_sv.diem_so, "ngay_cap": str(bc_sv.ngay_cap)} for bc_sv, loai_bc in ket_qua]}

@app.post("/api/sinh-vien/bang-cap")
def them_bang_cap(req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ngay_cap = datetime.strptime(req.get("ngay_cap"), "%Y-%m-%d").date() if req.get("ngay_cap") else None
    db.add(models.BangCapSinhVien(ma_tai_khoan=current_user.ma_tai_khoan, ma_loai_bang_cap=req.get("ma_loai_bang_cap"), diem_so=req.get("diem_so"), ngay_cap=ngay_cap))
    db.commit(); return {"message": "Thêm bằng cấp thành công!"}

# ==========================================
# API NHÓM HỌC & BÀI ĐĂNG
# ==========================================
@app.post("/api/nhom/tao-moi")
def tao_nhom_moi(req: TaoNhomRequest, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    mon_hoc = db.query(models.MonHoc).filter(models.MonHoc.ma_mon_hoc == req.ma_mon_hoc).first()
    new_nhom = models.NhomHoc(
        ten_nhom=req.ten_nhom, mo_ta=req.mo_ta, ma_mon_hoc=req.ma_mon_hoc, ten_mon_hoc=mon_hoc.ten_mon_hoc if mon_hoc else "",
        linh_vuc=req.linh_vuc, mo_ta_de_tai=req.mo_ta_de_tai, muc_tieu=req.muc_tieu,
        hinh_thuc_hoat_dong=req.hinh_thuc_hoat_dong, dia_diem_co_dinh=req.dia_diem_co_dinh,
        so_thanh_vien_toi_da=req.so_thanh_vien_toi_da, nguoi_tao=current_user.ma_tai_khoan,
        trang_thai='hoat_dong', so_thanh_vien_hien_tai=1, ngay_tao=datetime.now()
    )
    db.add(new_nhom); db.commit(); db.refresh(new_nhom)
    db.add(models.ThanhVienNhom(ma_nhom=new_nhom.ma_nhom, ma_tai_khoan=current_user.ma_tai_khoan, vai_tro='truong_nhom', ngay_tham_gia=datetime.now(), trang_thai='hoat_dong'))
    db.commit(); return {"message": "Tạo nhóm thành công!"}

@app.post("/api/nhom/{ma_nhom}/tao-bai-dang")
def tao_bai_dang(ma_nhom: int, req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. KIỂM TRA XEM NHÓM ĐÃ CÓ BÀI ĐĂNG NÀO ĐANG MỞ CHƯA
    bai_dang_hien_tai = db.query(models.BaiDangTuyen).filter(
        models.BaiDangTuyen.ma_nhom == ma_nhom,
        models.BaiDangTuyen.trang_thai == 'dang_mo'
    ).first()
    
    if bai_dang_hien_tai:
        return {"error": "Nhóm này đã có một bài đăng tuyển đang mở. Vui lòng đóng bài cũ trước khi tạo bài mới!"}

    # 2. Nếu chưa có, tiến hành tạo bài đăng như bình thường
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == ma_nhom).first()
    han_chot_date = datetime.strptime(req.get("han_chot"), "%Y-%m-%d").date() if req.get("han_chot") else None
    
    new_bd = models.BaiDangTuyen(
        ma_nhom=ma_nhom, nguoi_dang=current_user.ma_tai_khoan,
        tieu_de=f"Tìm thành viên nhóm {nhom.ten_mon_hoc or nhom.ten_nhom}", mo_ta=nhom.mo_ta,
        so_luong_can_tuyen=req.get("so_luong_can_tuyen", 1), trang_thai="dang_mo", ngay_tao=datetime.now(),
        han_chot=han_chot_date,
        yeu_cau_cung=req.get("yeu_cau_cung", ""), yeu_cau_mem=req.get("yeu_cau_mem", ""),
        yeu_cau_gpa=req.get("yeu_cau_gpa", 0.0), yeu_cau_ky_nang=req.get("yeu_cau_ky_nang", ""), yeu_cau_so_thich=req.get("yeu_cau_so_thich", "")
    )
    db.add(new_bd); db.commit(); return {"message": "Đăng tuyển thành công!"}

@app.get("/api/bai-dang")
def lay_danh_sach_bai_dang(authorization: str = Header(None), db: Session = Depends(get_db)):
    sinh_vien = None
    if authorization and authorization.startswith("Bearer "):
        try:
            payload = jwt.decode(authorization.split(" ")[1], SECRET_KEY, algorithms=[ALGORITHM])
            sinh_vien = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == int(payload.get("sub"))).first()
        except: pass

    bai_dangs = db.query(models.BaiDangTuyen, models.NhomHoc).join(models.NhomHoc, models.BaiDangTuyen.ma_nhom == models.NhomHoc.ma_nhom).filter(models.BaiDangTuyen.trang_thai == 'dang_mo', models.NhomHoc.trang_thai != 'da_giai_tan').all()
    
    ket_qua = []
    for bd, nhom in bai_dangs:
        diem = tinh_diem_tuong_thich(db, sinh_vien, nhom, bd) if sinh_vien else 0.5
        ket_qua.append({
            "maBaiDang": bd.ma_bai_dang, "maNhom": bd.ma_nhom, "tenNhom": nhom.ten_nhom,
            "tieuDe": bd.tieu_de, "moTaBaiDang": bd.mo_ta, "soLuongCanTuyen": bd.so_luong_can_tuyen,
            "hinhThuc": nhom.hinh_thuc_hoat_dong, "diaDiem": nhom.dia_diem_co_dinh,
            "soThanhVienHienTai": nhom.so_thanh_vien_hien_tai, "soThanhVienToiDa": nhom.so_thanh_vien_toi_da,
            "tenMonHoc": nhom.ten_mon_hoc, "linhVuc": nhom.linh_vuc,
            "yeuCauCung": bd.yeu_cau_cung, "yeuCauMem": bd.yeu_cau_mem,
            "yeuCauGpa": bd.yeu_cau_gpa, "yeuCauKyNang": bd.yeu_cau_ky_nang, 
            "diemTuongThich": diem, "ngayTao": str(bd.ngay_tao)
        })
    return {"danhSach": ket_qua}

@app.post("/api/bai-dang/{ma_bai_dang}/ung-tuyen")
def ung_tuyen(ma_bai_dang: int, req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    bd = db.query(models.BaiDangTuyen).filter(models.BaiDangTuyen.ma_bai_dang == ma_bai_dang).first()
    db.add(models.YeuCauThamGia(ma_bai_dang=ma_bai_dang, ma_nhom=bd.ma_nhom, nguoi_ung_tuyen=current_user.ma_tai_khoan, loi_nhan=req.get("loi_nhan", ""), trang_thai="cho_duyet", ngay_tao=datetime.now()))
    db.commit(); return {"message": "Gửi ứng tuyển thành công!"}

@app.get("/api/nhom/cua-toi")
def lay_nhom_cua_toi(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Lấy TẤT CẢ các nhóm, bao gồm cả nhóm đã giải tán
    ket_qua = db.query(models.ThanhVienNhom, models.NhomHoc).join(
        models.NhomHoc, models.ThanhVienNhom.ma_nhom == models.NhomHoc.ma_nhom
    ).filter(
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan
    ).all()
    
    return {"danhSach": [{
        "maNhom": nhom.ma_nhom, 
        "tenNhom": nhom.ten_nhom, 
        "moTa": nhom.mo_ta, 
        "soThanhVienHienTai": nhom.so_thanh_vien_hien_tai, 
        "soThanhVienToiDa": nhom.so_thanh_vien_toi_da, 
        "trangThai": nhom.trang_thai,  # <-- TRƯỜNG QUAN TRỌNG ĐỂ LỌC
        "vaiTro": tv.vai_tro, 
        "tenMonHoc": nhom.ten_mon_hoc
    } for tv, nhom in ket_qua]}

@app.get("/api/nhom/yeu-cau-gui-di")
def lay_yeu_cau_gui_di(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.YeuCauThamGia, models.NhomHoc).join(models.NhomHoc, models.YeuCauThamGia.ma_nhom == models.NhomHoc.ma_nhom).filter(models.YeuCauThamGia.nguoi_ung_tuyen == current_user.ma_tai_khoan).order_by(models.YeuCauThamGia.ngay_tao.desc()).all()
    return {"danhSach": [{"maYeuCau": yc.ma_yeu_cau, "maNhom": nhom.ma_nhom, "tenNhom": nhom.ten_nhom, "moTa": nhom.mo_ta, "soThanhVienHienTai": nhom.so_thanh_vien_hien_tai, "soThanhVienToiDa": nhom.so_thanh_vien_toi_da, "trangThai": yc.trang_thai, "tenMonHoc": nhom.ten_mon_hoc, "ngayTao": str(yc.ngay_tao)} for yc, nhom in ket_qua]}

@app.get("/api/nhom/{ma_nhom}/chi-tiet")
def lay_chi_tiet_nhom(ma_nhom: int, db: Session = Depends(get_db)):
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == ma_nhom).first()
    return {"maNhom": nhom.ma_nhom, "tenNhom": nhom.ten_nhom, "moTa": nhom.mo_ta, "tenMonHoc": nhom.ten_mon_hoc, "linhVuc": nhom.linh_vuc, "soThanhVienHienTai": nhom.so_thanh_vien_hien_tai, "soThanhVienToiDa": nhom.so_thanh_vien_toi_da, "hinhThucHoatDong": nhom.hinh_thuc_hoat_dong, "diaDiemCoDinh": nhom.dia_diem_co_dinh, "trangThai": nhom.trang_thai}

@app.get("/api/nhom/{ma_nhom}/thanh-vien")
def lay_thanh_vien(ma_nhom: int, db: Session = Depends(get_db)):
    ket_qua = db.query(models.ThanhVienNhom, models.SinhVien).join(
        models.SinhVien, models.ThanhVienNhom.ma_tai_khoan == models.SinhVien.ma_tai_khoan
    ).filter(models.ThanhVienNhom.ma_nhom == ma_nhom).all()
    
    return {"danhSach": [{
        "maTaiKhoan": tv.ma_tai_khoan, 
        "hoTen": sv.ho_ten, 
        "vaiTro": tv.vai_tro, 
        "ngayThamGia": str(tv.ngay_tham_gia),
        "anh_dai_dien": sv.anh_dai_dien or "" # <-- THÊM DÒNG NÀY
    } for tv, sv in ket_qua]}

@app.get("/api/nhom/{ma_nhom}/yeu-cau-cho-duyet")
def lay_yeu_cau_cho_duyet(ma_nhom: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.YeuCauThamGia, models.SinhVien).join(models.SinhVien, models.YeuCauThamGia.nguoi_ung_tuyen == models.SinhVien.ma_tai_khoan).filter(models.YeuCauThamGia.ma_nhom == ma_nhom, models.YeuCauThamGia.trang_thai == 'cho_duyet').all()
    return {"danhSach": [{"maYeuCau": yc.ma_yeu_cau, "maTaiKhoan": sv.ma_tai_khoan, "hoTen": sv.ho_ten, "mssv": sv.mssv, "chuyenNganh": sv.chuyen_nganh or "Chưa cập nhật", "loiNhan": yc.loi_nhan or "", "ngayGui": str(yc.ngay_tao)} for yc, sv in ket_qua]}

@app.post("/api/nhom/yeu-cau/{ma_yeu_cau}/duyet")
def duyet_yeu_cau(ma_yeu_cau: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    yc = db.query(models.YeuCauThamGia).filter(models.YeuCauThamGia.ma_yeu_cau == ma_yeu_cau).first()
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == yc.ma_nhom).first()
    yc.trang_thai = 'da_chap_nhan'; yc.nguoi_duyet = current_user.ma_tai_khoan
    db.add(models.ThanhVienNhom(ma_nhom=yc.ma_nhom, ma_tai_khoan=yc.nguoi_ung_tuyen, vai_tro='thanh_vien', trang_thai='hoat_dong', ngay_tham_gia=datetime.now()))
    nhom.so_thanh_vien_hien_tai += 1; db.commit(); return {"message": "Đã duyệt!"}

@app.post("/api/nhom/yeu-cau/{ma_yeu_cau}/tu-choi")
def tu_choi_yeu_cau(ma_yeu_cau: int, req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    yc = db.query(models.YeuCauThamGia).filter(models.YeuCauThamGia.ma_yeu_cau == ma_yeu_cau).first()
    yc.trang_thai = 'da_tu_choi'; yc.nguoi_duyet = current_user.ma_tai_khoan; yc.ly_do_tu_choi = req.get("ly_do", "")
    db.commit(); return {"message": "Đã từ chối!"}

# ============================================
# API MỚI: THÊM, XÓA THÀNH VIÊN, GIẢI TÁN NHÓM
# ============================================
@app.post("/api/nhom/{ma_nhom}/them-thanh-vien")
def them_thanh_vien(ma_nhom: int, req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom, 
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen: raise HTTPException(status_code=403, detail="Bạn không phải trưởng nhóm!")
    
    mssv = req.get("mssv")
    if not mssv: return {"error": "Vui lòng nhập mã sinh viên!"}
    
    sv = db.query(models.SinhVien).filter(models.SinhVien.mssv == mssv).first()
    if not sv: return {"error": "Không tìm thấy sinh viên với mã này!"}
    
    # Kiểm tra xem đã trong nhóm chưa
    existing = db.query(models.ThanhVienNhom).filter(models.ThanhVienNhom.ma_nhom == ma_nhom, models.ThanhVienNhom.ma_tai_khoan == sv.ma_tai_khoan).first()
    if existing: return {"error": "Sinh viên này đã ở trong nhóm!"}
    
    # Kiểm tra xem đã gửi lời mời chưa
    da_moi = db.query(models.YeuCauThamGia).filter(
        models.YeuCauThamGia.ma_nhom == ma_nhom, 
        models.YeuCauThamGia.nguoi_ung_tuyen == sv.ma_tai_khoan,
        models.YeuCauThamGia.trang_thai == 'da_moi'
    ).first()
    if da_moi: return {"error": "Đã gửi lời mời cho sinh viên này rồi!"}
    
    # Tạo lời mời (trạng thái da_moi)
    new_loi_moi = models.YeuCauThamGia(
        ma_nhom=ma_nhom, 
        nguoi_ung_tuyen=sv.ma_tai_khoan, 
        loi_nhan=f"Trưởng nhóm đã mời bạn tham gia nhóm.",
        trang_thai='da_moi', 
        ngay_tao=datetime.now(),
        nguoi_duyet=current_user.ma_tai_khoan
    )
    db.add(new_loi_moi)
    db.commit()
    return {"message": f"Đã gửi lời mời đến {sv.ho_ten}!"}

@app.delete("/api/nhom/{ma_nhom}/thanh-vien/{ma_tai_khoan}")
def xoa_thanh_vien(ma_nhom: int, ma_tai_khoan: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom, 
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen: raise HTTPException(status_code=403, detail="Bạn không phải trưởng nhóm!")
    
    # 2. Không cho phép xóa chính mình
    if ma_tai_khoan == current_user.ma_tai_khoan: return {"error": "Không thể tự xóa bản thân!"}
    
    # 3. Xóa khỏi nhóm
    tv = db.query(models.ThanhVienNhom).filter(models.ThanhVienNhom.ma_nhom == ma_nhom, models.ThanhVienNhom.ma_tai_khoan == ma_tai_khoan).first()
    if not tv: return {"error": "Thành viên không tồn tại trong nhóm!"}
    
    db.delete(tv)
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == ma_nhom).first()
    if nhom.so_thanh_vien_hien_tai > 0: nhom.so_thanh_vien_hien_tai -= 1
    db.commit()
    return {"message": "Đã xóa thành viên khỏi nhóm!"}

@app.delete("/api/nhom/{ma_nhom}/giai-tan")
def giai_tan_nhom(ma_nhom: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Kiểm tra quyền
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom, 
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen: raise HTTPException(status_code=403, detail="Bạn không phải trưởng nhóm!")
    
    # 2. Chuyển trạng thái nhóm thành đã giải tán
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == ma_nhom).first()
    nhom.trang_thai = 'da_giai_tan'
    
    # 3. Đóng tất cả bài đăng tuyển của nhóm này
    db.query(models.BaiDangTuyen).filter(models.BaiDangTuyen.ma_nhom == ma_nhom).update({"trang_thai": "da_dong"})
    
    db.commit()
    return {"message": "Đã giải tán nhóm thành công!"}

# ==========================================
# API ĐÁNH GIÁ
# ==========================================
@app.get("/api/nhom/{ma_nhom}/thanh-vien-danh-gia")
def lay_thanh_vien_danh_gia(ma_nhom: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.ThanhVienNhom, models.SinhVien).join(models.SinhVien, models.ThanhVienNhom.ma_tai_khoan == models.SinhVien.ma_tai_khoan).filter(models.ThanhVienNhom.ma_nhom == ma_nhom, models.ThanhVienNhom.ma_tai_khoan != current_user.ma_tai_khoan).all()
    danh_sach = []
    for tv, sv in ket_qua:
        da_danh_gia = db.query(models.DanhGia).filter(models.DanhGia.ma_nhom == ma_nhom, models.DanhGia.nguoi_danh_gia == current_user.ma_tai_khoan, models.DanhGia.nguoi_duoc_danh_gia == tv.ma_tai_khoan).first() is not None
        danh_sach.append({"maTaiKhoan": tv.ma_tai_khoan, "hoTen": sv.ho_ten, "vaiTro": "Trưởng nhóm" if tv.vai_tro == 'truong_nhom' else "Thành viên", "daDanhGia": da_danh_gia})
    return {"danhSach": danh_sach}

@app.post("/api/danh-gia")
def gui_danh_gia(req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ma_nhom = req.get("maNhom")
    nguoi_duoc_danh_gia = req.get("maNguoiDuocDanhGia")
    
    # 1. Kiểm tra xem đã đánh giá chưa
    existing = db.query(models.DanhGia).filter(
        models.DanhGia.ma_nhom == ma_nhom, models.DanhGia.nguoi_danh_gia == current_user.ma_tai_khoan,
        models.DanhGia.nguoi_duoc_danh_gia == nguoi_duoc_danh_gia
    ).first()
    if existing: return {"error": "Bạn đã đánh giá thành viên này rồi!"}

    # 2. Tính điểm trung bình của lần đánh giá này
    d_thai_do = req.get("diemThaiDo", 0)
    d_dong_gop = req.get("diemDongGop", 0)
    d_giao_tiep = req.get("diemGiaoTiep", 0)
    d_dung_han = req.get("diemDungHan", 0)
    diem_tb_lan_nay = (d_thai_do + d_dong_gop + d_giao_tiep + d_dung_han) / 4.0

    # 3. Lưu đánh giá vào DB
    new_dg = models.DanhGia(
        ma_nhom=ma_nhom, nguoi_danh_gia=current_user.ma_tai_khoan, nguoi_duoc_danh_gia=nguoi_duoc_danh_gia,
        diem_thai_do=d_thai_do, diem_dong_gop=d_dong_gop, diem_giao_tiep=d_giao_tiep, diem_dung_han=d_dung_han,
        diem_trung_binh=diem_tb_lan_nay, nhan_xet=req.get("nhanXet", ""), ngay_danh_gia=datetime.now()
    )
    db.add(new_dg)
    db.commit()

    # ==========================================
    # 4. TÍNH LẠI ĐIỂM UY TÍN CỦA NGƯỜI ĐƯỢC ĐÁNH GIÁ
    # ==========================================
    # Lấy tất cả điểm trung bình mà người này đã nhận được
    tat_ca_danh_gia = db.query(models.DanhGia).filter(models.DanhGia.nguoi_duoc_danh_gia == nguoi_duoc_danh_gia).all()
    
    if tat_ca_danh_gia:
        # Tính tổng điểm và chia cho số lượng đánh giá
        tong_diem = sum([dg.diem_trung_binh for dg in tat_ca_danh_gia])
        diem_uy_tin_moi = round(tong_diem / len(tat_ca_danh_gia), 2)
        
        # Cập nhật lại điểm uy tín cho sinh viên
        sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == nguoi_duoc_danh_gia).first()
        if sv:
            sv.diem_uy_tin = diem_uy_tin_moi
            db.commit()

    return {"message": "Gửi đánh giá thành công!"}

@app.get("/api/nhom/{ma_nhom}/thanh-vien-danh-gia")
def lay_thanh_vien_danh_gia(ma_nhom: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Lấy danh sách thành viên (trừ bản thân người đang đăng nhập ra)
    ket_qua = db.query(models.ThanhVienNhom, models.SinhVien).join(
        models.SinhVien, models.ThanhVienNhom.ma_tai_khoan == models.SinhVien.ma_tai_khoan
    ).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom, 
        models.ThanhVienNhom.ma_tai_khoan != current_user.ma_tai_khoan
    ).all()

    danh_sach = []
    for tv, sv in ket_qua:
        # Kiểm tra xem người dùng hiện tại đã đánh giá người này chưa
        da_danh_gia = db.query(models.DanhGia).filter(
            models.DanhGia.ma_nhom == ma_nhom, 
            models.DanhGia.nguoi_danh_gia == current_user.ma_tai_khoan,
            models.DanhGia.nguoi_duoc_danh_gia == tv.ma_tai_khoan
        ).first() is not None

        danh_sach.append({
            "maTaiKhoan": tv.ma_tai_khoan, 
            "hoTen": sv.ho_ten,
            "vaiTro": "Trưởng nhóm" if tv.vai_tro == 'truong_nhom' else "Thành viên",
            "daDanhGia": da_danh_gia
        })
    return {"danhSach": danh_sach}

from fastapi import WebSocket, WebSocketDisconnect
from typing import List, Dict

# ==========================================
# API & WEBSOCKET CHAT NHÓM
# ==========================================
class ConnectionManager:
    def __init__(self):
        # Lưu danh sách các kết nối: {ma_nhom: [WebSocket1, WebSocket2...]}
        self.active_connections: Dict[int, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, ma_nhom: int):
        await websocket.accept()
        if ma_nhom not in self.active_connections:
            self.active_connections[ma_nhom] = []
        self.active_connections[ma_nhom].append(websocket)

    def disconnect(self, websocket: WebSocket, ma_nhom: int):
        if ma_nhom in self.active_connections:
            if websocket in self.active_connections[ma_nhom]:
                self.active_connections[ma_nhom].remove(websocket)

    async def broadcast(self, message: dict, ma_nhom: int):
        if ma_nhom in self.active_connections:
            for connection in self.active_connections[ma_nhom]:
                await connection.send_json(message)

manager = ConnectionManager()

@app.websocket("/ws/chat/{ma_nhom}/{ma_tai_khoan}")
async def websocket_endpoint(websocket: WebSocket, ma_nhom: int, ma_tai_khoan: int, db: Session = Depends(get_db)):
    await manager.connect(websocket, ma_nhom)
    
    # Lấy thông tin người gửi (Tên + Avatar)
    sv = db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == ma_tai_khoan).first()
    ten_nguoi_gui = sv.ho_ten if sv else "Sinh viên"
    avatar_nguoi_gui = sv.anh_dai_dien if sv and sv.anh_dai_dien else ""
    
    try:
        while True:
            data = await websocket.receive_text()
            
            # Lưu vào Database
            new_msg = models.TinNhan(ma_nhom=ma_nhom, nguoi_gui=ma_tai_khoan, noi_dung=data)
            db.add(new_msg)
            db.commit()
            db.refresh(new_msg)
            
            # Gửi tin nhắn kèm Avatar
            msg_data = {
                "ma_tin_nhan": new_msg.ma_tin_nhan,
                "ma_tai_khoan": ma_tai_khoan,
                "ten_nguoi_gui": ten_nguoi_gui,
                "anh_dai_dien": avatar_nguoi_gui,
                "noi_dung": data,
                "ngay_gui": new_msg.ngay_gui.strftime("%H:%M")
            }
            await manager.broadcast(msg_data, ma_nhom)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, ma_nhom)

@app.get("/api/nhom/{ma_nhom}/tin-nhan")
def lay_lich_su_tin_nhan(ma_nhom: int, db: Session = Depends(get_db)):
    ket_qua = db.query(models.TinNhan, models.SinhVien).join(
        models.SinhVien, models.TinNhan.nguoi_gui == models.SinhVien.ma_tai_khoan
    ).filter(models.TinNhan.ma_nhom == ma_nhom).order_by(models.TinNhan.ngay_gui.asc()).limit(50).all()

    return [{
        "ma_tin_nhan": tn.ma_tin_nhan,
        "ma_tai_khoan": tn.nguoi_gui,
        "ten_nguoi_gui": sv.ho_ten,
        "anh_dai_dien": sv.anh_dai_dien or "", # TRẢ VỀ AVATAR
        "noi_dung": tn.noi_dung,
        "ngay_gui": tn.ngay_gui.strftime("%H:%M")
    } for tn, sv in ket_qua]

from pydantic import BaseModel
from datetime import datetime

# ==========================================
# API LỊCH HỌP NHÓM
# ==========================================
class TaoLichHopRequest(BaseModel):
    tieu_de: str
    thoi_gian_bat_dau: str # Định dạng ISO: YYYY-MM-DDTHH:MM
    thoi_gian_ket_thuc: str
    dia_diem: str = ""
    noi_dung: str = ""

@app.post("/api/nhom/{ma_nhom}/lich-hop")
def tao_lich_hop(ma_nhom: int, req: TaoLichHopRequest, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền tạo lịch họp!")

    try:
        # Parse thời gian
        start_time = datetime.fromisoformat(req.thoi_gian_bat_dau)
        end_time = datetime.fromisoformat(req.thoi_gian_ket_thuc)
        
        if end_time <= start_time:
            return {"error": "Thời gian kết thúc phải sau thời gian bắt đầu!"}

        new_lich = models.LichHop(
            ma_nhom=ma_nhom,
            tieu_de=req.tieu_de,
            thoi_gian_bat_dau=start_time,
            thoi_gian_ket_thuc=end_time,
            dia_diem=req.dia_diem,
            noi_dung=req.noi_dung,
            nguoi_tao=current_user.ma_tai_khoan
        )
        db.add(new_lich)
        db.commit()
        db.refresh(new_lich)
        return {"message": "Tạo lịch họp thành công!", "ma_lich_hop": new_lich.ma_lich_hop}
    except ValueError:
        return {"error": "Định dạng thời gian không hợp lệ!"}

@app.get("/api/nhom/{ma_nhom}/lich-hop")
def lay_danh_sach_lich_hop(ma_nhom: int, db: Session = Depends(get_db)):
    ket_qua = db.query(models.LichHop, models.SinhVien).join(
        models.SinhVien, models.LichHop.nguoi_tao == models.SinhVien.ma_tai_khoan
    ).filter(models.LichHop.ma_nhom == ma_nhom).order_by(models.LichHop.thoi_gian_bat_dau.asc()).all()
    
    return [{
        "ma_lich_hop": lh.ma_lich_hop,
        "tieu_de": lh.tieu_de,
        "thoi_gian_bat_dau": lh.thoi_gian_bat_dau.strftime("%Y-%m-%dT%H:%M:%S"),
        "thoi_gian_ket_thuc": lh.thoi_gian_ket_thuc.strftime("%Y-%m-%dT%H:%M:%S"),
        "dia_diem": lh.dia_diem,
        "noi_dung": lh.noi_dung,
        "nguoi_tao": sv.ho_ten
    } for lh, sv in ket_qua]

@app.delete("/api/nhom/{ma_nhom}/lich-hop/{ma_lich_hop}")
def xoa_lich_hop(ma_nhom: int, ma_lich_hop: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền xóa lịch họp!")

    lich = db.query(models.LichHop).filter(models.LichHop.ma_lich_hop == ma_lich_hop, models.LichHop.ma_nhom == ma_nhom).first()
    if not lich: return {"error": "Lịch họp không tồn tại!"}
    db.delete(lich)
    db.commit()
    return {"message": "Đã xóa lịch họp!"}

@app.get("/api/nhom/{ma_nhom}/lich-hop")
def lay_danh_sach_lich_hop(ma_nhom: int, db: Session = Depends(get_db)):
    try:
        # Truy vấn lấy tất cả lịch họp của nhóm
        ket_qua = db.query(models.LichHop, models.SinhVien).outerjoin(
            models.SinhVien, models.LichHop.nguoi_tao == models.SinhVien.ma_tai_khoan
        ).filter(models.LichHop.ma_nhom == ma_nhom).order_by(models.LichHop.thoi_gian_bat_dau.asc()).all()
        
        danh_sach = []
        for lh, sv in ket_qua:
            # Xử lý an toàn nếu ngày tháng bị lỗi
            start_str = lh.thoi_gian_bat_dau.strftime("%Y-%m-%dT%H:%M:%S") if lh.thoi_gian_bat_dau else ""
            end_str = lh.thoi_gian_ket_thuc.strftime("%Y-%m-%dT%H:%M:%S") if lh.thoi_gian_ket_thuc else ""
            
            danh_sach.append({
                "ma_lich_hop": lh.ma_lich_hop,
                "tieu_de": lh.tieu_de,
                "thoi_gian_bat_dau": start_str,
                "thoi_gian_ket_thuc": end_str,
                "dia_diem": lh.dia_diem or "",
                "noi_dung": lh.noi_dung or "",
                "nguoi_tao": sv.ho_ten if sv else "Ẩn danh"
            })
        return danh_sach
    except Exception as e:
        print("LỖI API LỊCH HỌP:", str(e)) # In lỗi ra Terminal để dễ debug
        raise HTTPException(status_code=500, detail="Lỗi server khi tải lịch họp")

# ==========================================
# API QUẢN LÝ LỊCH HỌP NHÓM
# ==========================================
from pydantic import BaseModel
from datetime import datetime

class TaoLichHopRequest(BaseModel):
    tieu_de: str
    thoi_gian_bat_dau: str
    thoi_gian_ket_thuc: str
    dia_diem: str = ""
    noi_dung: str = ""

@app.post("/api/nhom/{ma_nhom}/lich-hop")
def tao_lich_hop(ma_nhom: int, req: TaoLichHopRequest, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền tạo lịch họp!")

    try:
        # Parse thời gian từ Frontend gửi lên (YYYY-MM-DDTHH:MM)
        start_time = datetime.fromisoformat(req.thoi_gian_bat_dau)
        end_time = datetime.fromisoformat(req.thoi_gian_ket_thuc)
        
        if end_time <= start_time:
            return {"error": "Thời gian kết thúc phải sau thời gian bắt đầu!"}

        new_lich = models.LichHop(
            ma_nhom=ma_nhom,
            tieu_de=req.tieu_de,
            thoi_gian_bat_dau=start_time,
            thoi_gian_ket_thuc=end_time,
            dia_diem=req.dia_diem,
            noi_dung=req.noi_dung,
            nguoi_tao=current_user.ma_tai_khoan
        )
        db.add(new_lich)
        db.commit()
        db.refresh(new_lich)
        return {"message": "Tạo lịch họp thành công!", "ma_lich_hop": new_lich.ma_lich_hop}
    except ValueError:
        return {"error": "Định dạng thời gian không hợp lệ!"}

@app.delete("/api/nhom/{ma_nhom}/lich-hop/{ma_lich_hop}")
def xoa_lich_hop(ma_nhom: int, ma_lich_hop: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền xóa lịch họp!")

    # 2. Tìm và xóa lịch họp
    lich = db.query(models.LichHop).filter(models.LichHop.ma_lich_hop == ma_lich_hop, models.LichHop.ma_nhom == ma_nhom).first()
    if not lich:
        return {"error": "Lịch họp không tồn tại!"}
        
    db.delete(lich)
    db.commit()
    return {"message": "Đã xóa lịch họp thành công!"}

# ==========================================
# API DEADLINE (HẠN CHÓT)
# ==========================================
class TaoDeadlineRequest(BaseModel):
    tieu_de: str
    mo_ta: str = ""
    han_chot: str

@app.post("/api/nhom/{ma_nhom}/deadline")
def tao_deadline(ma_nhom: int, req: TaoDeadlineRequest, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền tạo deadline!")

    try:
        han_chot_dt = datetime.fromisoformat(req.han_chot)
        new_dl = models.Deadline(
            ma_nhom=ma_nhom, tieu_de=req.tieu_de, mo_ta=req.mo_ta,
            han_chot=han_chot_dt, nguoi_tao=current_user.ma_tai_khoan
        )
        db.add(new_dl)
        db.commit()
        return {"message": "Tạo deadline thành công!"}
    except ValueError:
        return {"error": "Định dạng thời gian không hợp lệ!"}

@app.get("/api/nhom/{ma_nhom}/deadline")
def lay_danh_sach_deadline(ma_nhom: int, db: Session = Depends(get_db)):
    ket_qua = db.query(models.Deadline).filter(models.Deadline.ma_nhom == ma_nhom).order_by(models.Deadline.han_chot.asc()).all()
    return [{
        "ma_deadline": dl.ma_deadline,
        "tieu_de": dl.tieu_de,
        "mo_ta": dl.mo_ta or "",
        "han_chot": dl.han_chot.strftime("%Y-%m-%dT%H:%M:%S") if dl.han_chot else "",
        "trang_thai": dl.trang_thai
    } for dl in ket_qua]

@app.put("/api/nhom/{ma_nhom}/deadline/{ma_deadline}/trang-thai")
def doi_trang_thai_deadline(ma_nhom: int, ma_deadline: int, db: Session = Depends(get_db)):
    dl = db.query(models.Deadline).filter(models.Deadline.ma_deadline == ma_deadline, models.Deadline.ma_nhom == ma_nhom).first()
    if not dl: return {"error": "Không tìm thấy deadline!"}
    dl.trang_thai = 'da_xong' if dl.trang_thai == 'chua_xong' else 'chua_xong'
    db.commit()
    return {"message": "Đã cập nhật trạng thái!", "trang_thai_moi": dl.trang_thai}

@app.delete("/api/nhom/{ma_nhom}/deadline/{ma_deadline}")
@app.delete("/api/nhom/{ma_nhom}/deadline/{ma_deadline}")
def xoa_deadline(ma_nhom: int, ma_deadline: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom,
        models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen:
        raise HTTPException(status_code=403, detail="Chỉ trưởng nhóm mới có quyền xóa deadline!")

    dl = db.query(models.Deadline).filter(models.Deadline.ma_deadline == ma_deadline, models.Deadline.ma_nhom == ma_nhom).first()
    if not dl: return {"error": "Không tìm thấy deadline!"}
    db.delete(dl)
    db.commit()
    return {"message": "Đã xóa deadline!"}

@app.get("/api/nhom/loi-moi-cua-toi")
def lay_loi_moi(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.YeuCauThamGia, models.NhomHoc).join(
        models.NhomHoc, models.YeuCauThamGia.ma_nhom == models.NhomHoc.ma_nhom
    ).filter(
        models.YeuCauThamGia.nguoi_ung_tuyen == current_user.ma_tai_khoan,
        models.YeuCauThamGia.trang_thai == 'da_moi'
    ).all()
    
    return {"danhSach": [{
        "maYeuCau": yc.ma_yeu_cau, "maNhom": nhom.ma_nhom, "tenNhom": nhom.ten_nhom, 
        "moTa": nhom.mo_ta, "tenMonHoc": nhom.ten_mon_hoc,
        "nguoiMoi": db.query(models.SinhVien).filter(models.SinhVien.ma_tai_khoan == yc.nguoi_duyet).first().ho_ten if yc.nguoi_duyet else "Trưởng nhóm"
    } for yc, nhom in ket_qua]}

@app.post("/api/nhom/loi-moi/{ma_yeu_cau}/chap-nhan")
def chap_nhan_loi_moi(ma_yeu_cau: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    yc = db.query(models.YeuCauThamGia).filter(models.YeuCauThamGia.ma_yeu_cau == ma_yeu_cau).first()
    if not yc or yc.nguoi_ung_tuyen != current_user.ma_tai_khoan: return {"error": "Lời mời không hợp lệ!"}
    
    yc.trang_thai = 'da_chap_nhan'
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == yc.ma_nhom).first()
    nhom.so_thanh_vien_hien_tai += 1
    
    db.add(models.ThanhVienNhom(ma_nhom=yc.ma_nhom, ma_tai_khoan=current_user.ma_tai_khoan, vai_tro='thanh_vien', trang_thai='hoat_dong', ngay_tham_gia=datetime.now()))
    db.commit()
    return {"message": "Đã tham gia nhóm thành công!"}

@app.post("/api/nhom/loi-moi/{ma_yeu_cau}/tu-choi")
def tu_choi_loi_moi(ma_yeu_cau: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    yc = db.query(models.YeuCauThamGia).filter(models.YeuCauThamGia.ma_yeu_cau == ma_yeu_cau).first()
    if not yc or yc.nguoi_ung_tuyen != current_user.ma_tai_khoan: return {"error": "Lời mời không hợp lệ!"}
    yc.trang_thai = 'da_tu_choi'
    db.commit()
    return {"message": "Đã từ chối lời mời!"}
@app.get("/api/sinh-vien/lich-su-nhom")
def lay_lich_su_nhom(current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        # 1. Lấy tất cả các nhóm mà user này đã tham gia
        ds_tham_gia = db.query(models.ThanhVienNhom, models.NhomHoc).join(
            models.NhomHoc, models.ThanhVienNhom.ma_nhom == models.NhomHoc.ma_nhom
        ).filter(models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan).all()

        ket_qua = []
        for tv, nhom in ds_tham_gia:
            # 2. Tính điểm uy tín trung bình mà user nhận được trong nhóm này
            diem_tb = db.query(func.avg(models.DanhGia.diem_trung_binh)).filter(
                models.DanhGia.ma_nhom == nhom.ma_nhom,
                models.DanhGia.nguoi_duoc_danh_gia == current_user.ma_tai_khoan
            ).scalar()

            ket_qua.append({
                "maNhom": nhom.ma_nhom,
                "tenNhom": nhom.ten_nhom,
                "tenMonHoc": nhom.ten_mon_hoc,
                "vaiTro": tv.vai_tro,
                "trangThai": nhom.trang_thai,
                "ngayThamGia": tv.ngay_tham_gia.strftime("%d/%m/%Y") if tv.ngay_tham_gia else "",
                "diemUyTin": round(diem_tb, 2) if diem_tb is not None else None
            })
            
        return {"danhSach": ket_qua}
    except Exception as e:
        print("LỖI API LỊCH SỬ NHÓM:", str(e)) # In lỗi ra màn hình đen để dễ sửa
        raise HTTPException(status_code=500, detail="Lỗi server khi tải lịch sử")
@app.post("/api/nhom/{ma_nhom}/tao-bai-dang")
def tao_bai_dang(ma_nhom: int, req: dict, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Lấy thông tin nhóm để tự động điền mô tả nếu cần
    nhom = db.query(models.NhomHoc).filter(models.NhomHoc.ma_nhom == ma_nhom).first()
    
    # Tạo bài đăng mới
    new_bd = models.BaiDangTuyen(
        ma_nhom=ma_nhom, 
        nguoi_dang=current_user.ma_tai_khoan,
        tieu_de=f"Tìm thành viên nhóm {nhom.ten_mon_hoc or nhom.ten_nhom}", 
        mo_ta=nhom.mo_ta,
        so_luong_can_tuyen=req.get("so_luong_can_tuyen", 1), 
        trang_thai="dang_mo", 
        ngay_tao=datetime.now(),
        yeu_cau_cung=req.get("yeu_cau_cung", ""), 
        yeu_cau_mem=req.get("yeu_cau_mem", ""),
        yeu_cau_gpa=req.get("yeu_cau_gpa", 0.0), 
        yeu_cau_ky_nang=req.get("yeu_cau_ky_nang", ""), 
        yeu_cau_so_thich=req.get("yeu_cau_so_thich", "")
    )
    db.add(new_bd)
    db.commit()
    return {"message": "Đăng tuyển thành công!"}
# ==========================================
# API QUẢN LÝ BÀI ĐĂNG (DÀNH CHO TRƯỞNG NHÓM)
# ==========================================

# 1. Lấy danh sách bài đăng đang mở của nhóm
@app.get("/api/nhom/{ma_nhom}/bai-dang")
def lay_bai_dang_cua_nhom(ma_nhom: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    ket_qua = db.query(models.BaiDangTuyen).filter(
        models.BaiDangTuyen.ma_nhom == ma_nhom,
        models.BaiDangTuyen.trang_thai == 'dang_mo'
    ).all()
    return [{
        "maBaiDang": bd.ma_bai_dang,
        "tieuDe": bd.tieu_de,
        "soLuong": bd.so_luong_can_tuyen,
        "hanChot": str(bd.han_chot) if bd.han_chot else "Không có"
    } for bd in ket_qua]

# 2. Xóa (Gỡ) bài đăng
@app.delete("/api/nhom/{ma_nhom}/bai-dang/{ma_bai_dang}")
def xoa_bai_dang(ma_nhom: int, ma_bai_dang: int, current_user: models.TaiKhoan = Depends(get_current_user), db: Session = Depends(get_db)):
    # Kiểm tra quyền trưởng nhóm
    check_quyen = db.query(models.ThanhVienNhom).filter(
        models.ThanhVienNhom.ma_nhom == ma_nhom, models.ThanhVienNhom.ma_tai_khoan == current_user.ma_tai_khoan,
        models.ThanhVienNhom.vai_tro == 'truong_nhom'
    ).first()
    if not check_quyen: raise HTTPException(status_code=403, detail="Bạn không phải trưởng nhóm!")

    bd = db.query(models.BaiDangTuyen).filter(models.BaiDangTuyen.ma_bai_dang == ma_bai_dang, models.BaiDangTuyen.ma_nhom == ma_nhom).first()
    if not bd: return {"error": "Không tìm thấy bài đăng!"}
    
    db.delete(bd)
    db.commit()
    return {"message": "Đã gỡ bài đăng thành công!"}